<?php

/*
Plugin Name: Simple Download Monitor
Plugin URI: http://www.pepak.net/wordpress/simple-download-monitor-plugin
Description: Count the number of downloads without having to maintain a comprehensive download page.
Version: 0.11
Author: Pepak
Author URI: http://www.pepak.net
*/

/*  Copyright 2009, 2010  Pepak (email: wordpress@pepak.net)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if (!defined('SDMON_PREFIX'))
	define('SDMON_PREFIX', 'sdmon_');
if (!defined('SDMON_VERSION'))
	define('SDMON_VERSION', '0.11');

if (!class_exists('SimpleDownloadMonitor'))
{
	class SimpleDownloadMonitor
	{

		var $PREG_DELIMITER = '`';
		var $GET_PARAM = 'sdmon';
		var $RECORDS_PER_PAGE = 20;
		var $GETTEXT_REALM = 'simple-download-monitor';

		var $plugin_url = '';
		var $plugin_dir = '';
		var $plugin_dir_relative = '';

		function SimpleDownloadMonitor()
		{
			$this->plugin_url = WP_PLUGIN_URL . '/' . dirname(plugin_basename(__FILE__));
			$this->plugin_dir = WP_PLUGIN_DIR . '/' . dirname(plugin_basename(__FILE__));
			if (strpos($this->plugin_dir, ABSPATH) === 0)
				$this->plugin_dir_relative = substr($this->plugin_dir, strlen(ABSPATH));
			else
				$this->plugin_dir_relative = $this->plugin_dir;
			register_activation_hook(__FILE__, array('SimpleDownloadMonitor', 'Install'));
			add_action('init', array(&$this, 'ActionInit'));
			add_action('admin_menu', 'SimpleDownloadMonitor_BuildAdminMenu');
		}

		static function Install()
		{
			global $wpdb;
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			$table_downloads = $wpdb->prefix . SDMON_PREFIX . 'downloads';
			$sql = "CREATE TABLE ${table_downloads} (
				id INTEGER NOT NULL AUTO_INCREMENT,
				filename VARCHAR(1024) NOT NULL,
				download_count INTEGER NOT NULL,
				last_date TIMESTAMP NOT NULL,
				file_exists TINYINT,
				PRIMARY KEY  id (id),
				KEY  download_count (download_count),
				KEY  last_date (last_date)
				);";
			dbDelta($sql);
			$table_details = $wpdb->prefix . SDMON_PREFIX . 'details';
			$sql = "CREATE TABLE ${table_details} (
				id INTEGER NOT NULL AUTO_INCREMENT,
				download INTEGER NOT NULL,
				download_date TIMESTAMP NOT NULL,
				ip VARCHAR(64) NOT NULL,
				referer TEXT,
				userid INTEGER,
				username VARCHAR(64),
				PRIMARY KEY  id (id),
				KEY  download (download),
				KEY  download_date (download_date)
				);";
			dbDelta($sql);
			update_option(SDMON_PREFIX . 'table_downloads', $table_downloads);
			update_option(SDMON_PREFIX . 'table_details', $table_details);
			update_option(SDMON_PREFIX . 'version', SDMON_VERSION);
			add_option(SDMON_PREFIX . 'directories', 'files/');
			add_option(SDMON_PREFIX . 'extensions', 'zip|rar|7z');
			add_option(SDMON_PREFIX . 'detailed', '0');
			add_option(SDMON_PREFIX . 'inline', '');
		}

		function table_downloads()
		{
			static $table = null;
			if ($table == null)
				$table = get_option(SDMON_PREFIX . 'table_downloads');
			return $table;
		}

		function table_details()
		{
			static $table = null;
			if ($table == null)
				$table = get_option(SDMON_PREFIX . 'table_details');
			return $table;
		}

		//-----------------------------------------------------------------------------------
		// Methods set_range, buffered_read, byteserve adapted from
		// http://www.coneural.org/florian/papers/04_byteserving.php

		function set_range($range, $filesize, &$first, &$last){
		  /*
		  Sets the first and last bytes of a range, given a range expressed as a string 
		  and the size of the file.

		  If the end of the range is not specified, or the end of the range is greater 
		  than the length of the file, $last is set as the end of the file.

		  If the begining of the range is not specified, the meaning of the value after 
		  the dash is "get the last n bytes of the file".

		  If $first is greater than $last, the range is not satisfiable, and we should 
		  return a response with a status of 416 (Requested range not satisfiable).

		  Examples:
		  $range='0-499', $filesize=1000 => $first=0, $last=499 .
		  $range='500-', $filesize=1000 => $first=500, $last=999 .
		  $range='500-1200', $filesize=1000 => $first=500, $last=999 .
		  $range='-200', $filesize=1000 => $first=800, $last=999 .

		  */
		  $dash=strpos($range,'-');
		  $first=trim(substr($range,0,$dash));
		  $last=trim(substr($range,$dash+1));
		  if ($first=='') {
		    //suffix byte range: gets last n bytes
		    $suffix=$last;
		    $last=$filesize-1;
		    $first=$filesize-$suffix;
		    if($first<0) $first=0;
		  } else {
		    if ($last=='' || $last>$filesize-1) $last=$filesize-1;
		  }
		  if($first>$last){
		    //unsatisfiable range
		    header("Status: 416 Requested range not satisfiable");
		    header("Content-Range: */$filesize");
		    exit;
		  }
		}

		function buffered_read($file, $bytes, $buffer_size=1024){
		  /*
		  Outputs up to $bytes from the file $file to standard output, $buffer_size bytes at a time.
		  */
		  $bytes_left=$bytes;
		  while($bytes_left>0 && !feof($file)){
		    if($bytes_left>$buffer_size)
		      $bytes_to_read=$buffer_size;
		    else
		      $bytes_to_read=$bytes_left;
		    $bytes_left-=$bytes_to_read;
		    $contents=fread($file, $bytes_to_read);
		    echo $contents;
		    flush();
		  }
		}

		function byteserve($filename, $mimetype, $disposition = ''){
		  /*
		  Byteserves the file $filename.  

		  When there is a request for a single range, the content is transmitted 
		  with a Content-Range header, and a Content-Length header showing the number 
		  of bytes actually transferred.

		  When there is a request for multiple ranges, these are transmitted as a 
		  multipart message. The multipart media type used for this purpose is 
		  "multipart/byteranges".
		  */

		  $filesize=filesize($filename);
		  $file=fopen($filename,"rb");

		  $ranges=NULL;
		  if ($_SERVER['REQUEST_METHOD']=='GET' && isset($_SERVER['HTTP_RANGE']) && $range=stristr(trim($_SERVER['HTTP_RANGE']),'bytes=')){
		    $range=substr($range,6);
		    $boundary=sha1(uniqid());//set a random boundary
		    $ranges=explode(',',$range);
		  }

		  if($ranges && count($ranges)){
		    header("HTTP/1.1 206 Partial content");
		    header("Accept-Ranges: bytes");
		    if(count($ranges)>1){
		      /*
		      More than one range is requested. 
		      */

		      //compute content length
		      $content_length=0;
		      foreach ($ranges as $range){
		        $this->set_range($range, $filesize, $first, $last);
		        $content_length+=strlen("\r\n--$boundary\r\n");
		        $content_length+=strlen("Content-type: $mimetype\r\n");
		        $content_length+=strlen("Content-range: bytes $first-$last/$filesize\r\n\r\n");
		        $content_length+=$last-$first+1;          
		      }
		      $content_length+=strlen("\r\n--$boundary--\r\n");

		      //output headers
		      header("Content-Length: $content_length");
		      //see http://httpd.apache.org/docs/misc/known_client_problems.html for an discussion of x-byteranges vs. byteranges
		      header("Content-Type: multipart/x-byteranges; boundary=$boundary");

		      //output the content
		      foreach ($ranges as $range){
		        $this->set_range($range, $filesize, $first, $last);
		        echo "\r\n--$boundary\r\n";
		        echo "Content-type: $mimetype\r\n";
		        echo "Content-range: bytes $first-$last/$filesize\r\n\r\n";
		        fseek($file,$first);
		        $this->buffered_read ($file, $last-$first+1);          
		      }
		      echo "\r\n--$boundary--\r\n";
		    } else {
		      /*
		      A single range is requested.
		      */
		      $range=$ranges[0];
		      $this->set_range($range, $filesize, $first, $last);  
		      header("Content-Length: ".($last-$first+1) );
		      header("Content-Range: bytes $first-$last/$filesize");
		      header("Content-Type: $mimetype");  
		      if ($disposition) 
		    	  header("Content-Disposition: $disposition");
		      fseek($file,$first);
		      $this->buffered_read($file, $last-$first+1);
		    }
		  } else{
		    //no byteserving
		    header("Accept-Ranges: bytes");
		    header("Content-Length: $filesize");
		    header("Content-Type: $mimetype");
		    if ($disposition) 
		    	header("Content-Disposition: $disposition");
		    readfile($filename);
		  }
		  fclose($file);
		}
		//-----------------------------------------------------------------------------------

		function Download($filename)
		{
			global $wpdb, $user_login, $user_ID;
			// Normalize the filename
			$fullfilename = realpath(ABSPATH . '/' . $filename);
			$relfilename = substr($fullfilename, strlen(ABSPATH));
			$relfilename = strtr($relfilename, '\\', '/');
			$exists = (file_exists($fullfilename) AND !is_dir($fullfilename)) ? 1 : 0;
			// Store uncorrected request name to database for security/mistake review
			$downloads = $this->table_downloads();
			$id = $wpdb->get_var($wpdb->prepare("SELECT id FROM ${downloads} WHERE filename=%s", $filename));
			if ($id)
			{
				$sql = "UPDATE ${downloads} SET download_count=download_count+1, last_date=NOW(), file_exists=%d WHERE id=%d";
				$wpdb->query($wpdb->prepare($sql, $exists, $id));
			}
			else
			{
				$sql = "INSERT INTO ${downloads} (filename, download_count, last_date, file_exists) VALUES (%s, 1, NOW(), %d)";
				$wpdb->query($wpdb->prepare($sql, $filename, $exists));
				$id = $wpdb->insert_id;
			}
			// If details are requested, store them as well
			if (intval(get_option(SDMON_PREFIX . 'detailed')))
			{
				$details = $this->table_details();
				$sql = "INSERT INTO ${details} (download, download_date, ip, referer, username, userid) VALUES (%d, NOW(), %s, %s, %s, %d)";
				get_currentuserinfo();
				$userid = $user_ID ? $user_ID : null;
				$username = $user_login ? $user_login : null;
				$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
				if (!$username AND isset($_COOKIE['comment_author_'.COOKIEHASH]))
					$username = utf8_encode($_COOKIE['comment_author_'.COOKIEHASH]);
				$wpdb->query($wpdb->prepare($sql, $id, $_SERVER['REMOTE_ADDR'], $referer, $username, $userid));
			}
			// Make sure the file is available for download
			if (!$exists)
				return FALSE;
			$dirregexp = $this->PREG_DELIMITER . '^' . get_option(SDMON_PREFIX . 'directories') . $this->PREG_DELIMITER;
			if (!preg_match($dirregexp, $relfilename))
				return FALSE;
			$extregexp = $this->PREG_DELIMITER . '\\.' . get_option(SDMON_PREFIX . 'extensions') . '$' . $this->PREG_DELIMITER;
			if (!preg_match($extregexp, $relfilename))
				return FALSE;
			// Generate proper headers
			$mimetype = '';
			if (function_exists('finfo_open'))
			{
				$finfo = finfo_open(FILEINFO_MIME_TYPE);
				$mimetype = finfo_file($finfo, $fullfilename);
			}
			if (!$mimetype && function_exists('mime_content_type'))
				$mimetype = mime_content_type($fullfilename);
			if (!$mimetype || ((strpos($mimetype, '/')) === FALSE))
				$mimetype = 'application/octet-stream';
			$disposition = 'attachment';
			$inlineregexp = $this->PREG_DELIMITER . get_option(SDMON_PREFIX . 'inline') . $this->PREG_DELIMITER;
			if ($inlineregexp && preg_match($inlineregexp, $relfilename))
				$disposition = 'inline';
			$disposition = $disposition . '; filename=' . basename($fullfilename);
			$this->byteserve($fullfilename, $mimetype, $disposition);
			// Successful end
			return TRUE;
		}

		function ActionInit() {
			// Function is called in 'init' hook. It checks for download and if so, stops normal WordPress processing
			// and replaces it with its monitoring functions.
			$currentLocale = get_locale();
			if(!empty($currentLocale))
			{
				$moFile = $this->plugin_dir . "/lang/" . $currentLocale . ".mo";
				if(@file_exists($moFile) && is_readable($moFile))
					load_textdomain($this->GETTEXT_REALM, $moFile);
			}
			//load_plugin_textdomain($this->GETTEXT_REALM, $this->plugin_dir . '/lang');
			if (isset($_GET[$this->GET_PARAM]) && ($filename = $_GET[$this->GET_PARAM]))
			{
				if ($this->Download($filename))
					die();
				else
					wp_redirect(get_option('site_url'));
			}
		}

		function AdminPanel()
		{
			// Function draws the admin panel.
			// First, post any modified options
			if (isset($_POST['SimpleDownloadMonitor_Submit']))
			{
				// Read options from the form
				$directories = strval($_POST[SDMON_PREFIX . 'directories']);
				$extensions = strval($_POST[SDMON_PREFIX . 'extensions']);
				$detailed = intval($_POST[SDMON_PREFIX . 'detailed']);
				$inline = strval($_POST[SDMON_PREFIX . 'inline']);
				// Remove slashes if necessary
				if (get_magic_quotes_gpc())
				{
					$directories = stripslashes($directories);
					$extensions = stripslashes($extensions);
					$inline = stripslashes($inline);
				}
				// Escape the delimiter
				list($directories, $extensions) = str_replace($this->PREG_DELIMITER, '\\'.$this->PREG_DELIMITER, array($directories, $extensions));
				// Write the changes to database
				update_option(SDMON_PREFIX . 'directories', $directories);
				update_option(SDMON_PREFIX . 'extensions', $extensions);
				update_option(SDMON_PREFIX . 'detailed', $detailed);
				update_option(SDMON_PREFIX . 'inline', $inline);
			}
			// Load options from the database
			$directories = get_option(SDMON_PREFIX . 'directories');
			$extensions = get_option(SDMON_PREFIX . 'extensions');
			$detailed = get_option(SDMON_PREFIX . 'detailed');
			$inline = get_option(SDMON_PREFIX . 'inline');
			// Build the form
			?>
<div class="wrap">
<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
	<h2><?php echo __('Simple Download Monitor options', $this->GETTEXT_REALM); ?></h2>
	<h3><?php echo __('Allowed directories', $this->GETTEXT_REALM); ?></h3>
	<p><?php echo __("Only requested files whose full names (relative to document root) start with this regular expression will be processed. It is strongly recommended to place all downloadable files (and ONLY downloadable files) into a designated directory and then placing that directory's name followed by a slash here. It is possible to use the power of PREG to allow multiple directories, but make sure there are ONLY files which you are comfortable with malicious users downloading. Do not EVER allow directories which contain PHP files here! That could lead to disclosure of sensitive data, including username and password used to connect to WordPress database.", $this->GETTEXT_REALM); ?></p>
	<p><?php echo __("Default value is <code>files/</code>, which only allows download from /files directory (the leading <code>/</code> is implicit).", $this->GETTEXT_REALM); ?></p>
	<p><input type="text" name="<?php echo SDMON_PREFIX; ?>directories" value="<?php echo attribute_escape($directories); ?>" /></p>
	<h3><?php echo __('Allowed extensions', $this->GETTEXT_REALM); ?></h3>
	<p><?php echo __('Only files with extensions matching this regular expressions will be processed. This is another important security value. Make sure you only add extensions which are safe for malicious users to have, e.g. archives and possibly images. Do NOT use any expression that could allow a user to download PHP files, even if you think it safe given the Allowed Directories option above.', $this->GETTEXT_REALM); ?></p>
	<p><?php echo __("Default value is <code>zip|rar|7z</code> which only allows download of files ending with <code>.zip</code>, <code>.rar</code> and <code>.7z</code> (the leading <code>.</code> is implicit).", $this->GETTEXT_REALM); ?></p>
	<p><input type="text" name="<?php echo SDMON_PREFIX; ?>extensions" value="<?php echo attribute_escape($extensions); ?>" /></p>
	<h3><?php echo __('Inline files', $this->GETTEXT_REALM); ?></h3>
	<p><?php echo __('Files whose names match this regular expression will be displayed inline (within a HTML page) rather than downloaded.', $this->GETTEXT_REALM); ?></p>
	<p><?php echo __("By default, this value is empty - no files will appear inline, all will be downloaded. You may want to place something like <code>\.(jpe?g|gif|png|swf)$</code> here to make images and Flash videos appear inline.", $this->GETTEXT_REALM); ?></p>
	<p><?php echo __('Note: Unlike the options above, nothing is implied in this regular expression. You <em>must</em> use an explicit <code>\.</code> to denote "start of extension", you <em>must</em> use an explicit <code>$</code> to mark "end of filename", etc.', $this->GETTEXT_REALM); ?></p>
	<p><input type="text" name="<?php echo SDMON_PREFIX; ?>inline" value="<?php echo attribute_escape($inline); ?>" /></p>
	<h3><?php echo __("Store detailed logs?", $this->GETTEXT_REALM); ?></h3>
	<p><?php echo __("If detailed logs are allowed, various information (including exact time of download, user's IP address, referrer etc.) is stored. This can fill your database quickly if you have only a little space or a lot of popular downloads. Otherwise just the total numbers of downloads are stored, consuming significantly less space.", $this->GETTEXT_REALM); ?></p>
	<p><label for="<?php echo SDMON_PREFIX; ?>detailed"><input type="checkbox" name="<?php echo SDMON_PREFIX; ?>detailed" value="1" <?php if ($detailed) echo 'checked="checked" '; ?>/> <?php echo __('Use detailed statistics.', $this->GETTEXT_REALM); ?></label></p>
	<div class="submit"><input type="submit" name="SimpleDownloadMonitor_Submit" value="<?php echo __("Update settings", $this->GETTEXT_REALM) ?>" /></div>
</form>
</div><?php
		}

		function ToolsPanel()
		{
			$download = isset($_GET['download']) ? intval($_GET['download']) : 0;
			$from = isset($_GET['from']) ? intval($_GET['from']) : 0;
			$order = isset($_GET['order']) ? $_GET['order'] : '';
			$flags = isset($_GET['flags']) ? intval($_GET['flags']) : 0;
			$detailed = get_option(SDMON_PREFIX . 'detailed');
			$options = array('download' => $download, 'from' => $from, 'order' => $order, 'flags' => $flags);
			if ($this->IsAdmin())
			{
				if (isset($_POST['SimpleDownloadMonitor_Delete']) && isset($_POST['SimpleDownloadMonitor_DeleteIds']) && is_array($_POST['SimpleDownloadMonitor_DeleteIds'])) 
				{
					$this->DeleteDownloads($_POST['SimpleDownloadMonitor_DeleteIds']);
				} 
				elseif (isset($_POST['SimpleDownloadMonitor_DeleteAll']) && ($_POST['SimpleDownloadMonitor_DeleteAllReally'] == 'yes')) 
				{
					$this->DeleteAllDownloads();
				}
				if (isset($_POST['SimpleDownloadMonitor_DeleteDetail']) && isset($_POST['SimpleDownloadMonitor_DeleteIds']) && is_array($_POST['SimpleDownloadMonitor_DeleteIds'])) 
				{
					$this->DeleteDownloadDetails($_POST['SimpleDownloadMonitor_DeleteIds']);
				} 
			}
			if ($detailed && $download)
				$this->DetailedDownloadList($options);
			else
				$this->DownloadList($options);
		}

		const ORDER_NAME    = 'name';
		const ORDER_COUNT   = 'count';
		const ORDER_DATE    = 'date';
		const ORDER_IP      = 'ip';
		const ORDER_REFERER = 'referer';
		const ORDER_USER    = 'user';

		function GetOrderBy($order = '')
		{
			static $orders = array(
				self::ORDER_NAME  => 'filename',
				self::ORDER_COUNT => 'download_count DESC, filename',
				self::ORDER_DATE  => 'last_date DESC, filename',
				);
			$result = isset($orders[$order]) ? $orders[$order] : $orders[self::ORDER_COUNT];
			$result = " ORDER BY ${result} ";
			return $result;
		}

		function GetDetailOrderBy($order = '')
		{
			static $orders = array(
				self::ORDER_DATE    => 'download_date DESC',
				self::ORDER_IP      => 'ip, download_date DESC',
				self::ORDER_REFERER => 'referer, download_date DESC',
				self::ORDER_USER    => 'username, download_date DESC',
				);
			$result = isset($orders[$order]) ? $orders[$order] : $orders[self::ORDER_DATE];
			$result = " ORDER BY ${result} ";
			return $result;
		}

		var $FLAGS_NOTEXISTING = 1;

		function GetWhere($flags = 0)
		{
			$conditions = array();
			if ($flags & $this->FLAGS_NOTEXISTING)
				$conditions[] = '(file_exists=0)';
			else
				$conditions[] = '(file_exists<>0)';
			if ($conditions)
				$result = ' WHERE ' . implode(' AND ', $conditions);
			else
				$result = '';
			return $result;
		}

		function GetDetailWhere($flags = 0)
		{
			$conditions = array();
			if ($conditions)
				$result = ' AND ' . implode(' AND ', $conditions);
			else
				$result = '';
			return $result;
		}

		function GetLimit($from = 0)
		{
			$from = intval($from);
			if ($from < 0)
				$from = 0;
			$count = $this->RECORDS_PER_PAGE;
			$result = " LIMIT ${from}, ${count} ";
			return $result;
		}

		function GetUrlForList($options = array(), $html = TRUE)
		{
			$amp = $html ? '&amp;' : '&';
			$result = get_option('site_url') . 'tools.php?page=' . basename(__FILE__);
			foreach ($options as $name => $value)
				if ($value)
					$result .= $amp . ($html ? htmlspecialchars($name) : $name) . '=' . ($html ? htmlspecialchars($value) : $value);
			return $result;

		}

		function Paginator($options, $count)
		{
			$from = intval($options['from']);
			$count = intval($count);
			$pages = array();
			if ($from > 0)
			{
				$pages[] = '<a href="' . $this->GetUrlForList(array_merge($options, array('from'=>0))) . '">' . __("First", $this->GETTEXT_REALM) . '</a>';
				$pages[] = '<a href="' . $this->GetUrlForList(array_merge($options, array('from'=>($from>$this->RECORDS_PER_PAGE ? $from-$this->RECORDS_PER_PAGE : 0)))) . '">' . __("Previous", $this->GETTEXT_REALM) . '</a>';
			}

			if (($from + $this->RECORDS_PER_PAGE) < $count)
			{
				$pages[] = '<a href="' . $this->GetUrlForList(array_merge($options, array('from'=>$from+$this->RECORDS_PER_PAGE))) . '">' . __("Next", $this->GETTEXT_REALM) . '</a>';
				$pages[] = '<a href="' . $this->GetUrlForList(array_merge($options, array('from'=>$count-$this->RECORDS_PER_PAGE))) . '">' . __("Last", $this->GETTEXT_REALM) . '</a>';
			}
			$result = $pages ? '<div class="pages-list">' . implode(' ', $pages) . '</div>' : '';
			return $result;
		}

		function IsAdmin()
		{
			if (current_user_can('delete_users'))
			/*
			global $user_level;
			get_currentuserinfo();
			if ($user_level >= 10)
			*/
				return TRUE;
			else
				return FALSE;
		}

		function DeleteDownloadDetails($ids = array())
		{
			global $wpdb;
			$ids = array_map('intval', $ids);
			if ($ids)
			{
				$ids = implode(',', $ids);
				$downloads = $this->table_downloads();
				$details = $this->table_details();
				$downloadids = array();
				$sql = "SELECT DISTINCT download FROM ${details} WHERE id IN (${ids})";
				$results = $wpdb->get_results($sql, ARRAY_N);
				if (is_array($results))
					foreach ($results as $row)
					{
						list($downloadid) = $row;
						$downloadids[] = $downloadid;
					}
				if ($downloadids) {
					$sql = "DELETE FROM ${details} WHERE id IN (${ids})";
					$wpdb->query($sql);
					foreach ($downloadids as $downloadid)
					{
						$sql = "SELECT COUNT(*), MAX(download_date) FROM ${details} WHERE download=%d";
						$result = $wpdb->get_row($wpdb->prepare($sql, $downloadid), ARRAY_N);
						if (is_array($result))
						{
							list($count, $date) = $result;
							$sql = "UPDATE ${downloads} SET download_count=%d, last_date=%s WHERE id=%d";
							$wpdb->query($wpdb->prepare($sql, $count, $date, $downloadid));
						}
					}
				}
			}
			//wp_redirect($_SERVER['REQUEST_URI']);
			//die();
		}

		function DeleteDownloads($ids = array())
		{
			global $wpdb;
			$ids = array_map('intval', $ids);
			if ($ids)
			{
				$ids = implode(',', $ids);
				$downloads = $this->table_downloads();
				$details = $this->table_details();
				$sql = "DELETE FROM ${downloads} WHERE id IN (${ids})";
				$wpdb->query($sql);
				$sql = "DELETE FROM ${details} WHERE download IN (${ids})";
				$wpdb->query($sql);
			}
			//wp_redirect($_SERVER['REQUEST_URI']);
			//die();
		}

		function DeleteAllDownloads()
		{
			global $wpdb;
			$downloads = $this->table_downloads();
			$details = $this->table_details();
			$sql = "DELETE FROM ${downloads}";
			$wpdb->query($sql);
			$sql = "DELETE FROM ${details}";
			$wpdb->query($sql);
			//wp_redirect($_SERVER['REQUEST_URI']);
			//die();
		}

		function DownloadList($options)
		{
			global $wpdb;
			$flags = $options['flags'];
			$from = $options['from'];
			$order = $options['order'];
			$detailed = get_option(SDMON_PREFIX . 'detailed');
			?>
<div class="wrap">
<h2><?php echo __('Simple Download Monitor', $this->GETTEXT_REALM); ?></h2>
<h3><?php echo ($options['flags'] & $this->FLAGS_NOTEXISTING) ? __('Nonexistent downloads', $this->GETTEXT_REALM) : __('All downloads', $this->GETTEXT_REALM); ?></h3>
<p><a href="<?php echo $this->GetUrlForList(array_merge($options, array('from' => 0, 'flags' => $options['flags']^$this->FLAGS_NOTEXISTING))); ?>"><?php echo ($options['flags'] & $this->FLAGS_NOTEXISTING) ? __('Show all downloads', $this->GETTEXT_REALM) : __('Show nonexistent downloads', $this->GETTEXT_REALM); ?></a></p>
<?php if ($this->isAdmin()): ?>
<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<?php endif; ?>
<table id="sdmon">
	<colgroup>
		<col class="sdmon-rownum" align="right" width="32" />
		<col class="sdmon-filename" />
		<col class="sdmon-count" align="right" width="64" />
		<col class="sdmon-date" align="center" />
		<col class="sdmon-tools" />
	</colgroup>
	<thead>
	<tr>
		<th>&nbsp;</th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_NAME ))); ?>"><?php echo __("Filename", $this->GETTEXT_REALM); ?></a></th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_COUNT))); ?>"><?php echo __("Download count", $this->GETTEXT_REALM); ?></a></th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_DATE ))); ?>"><?php echo __("Last date", $this->GETTEXT_REALM); ?></a></th>
		<th>&nbsp;</th>
	</tr>
	</thead>
	<tbody><?php
			$table_downloads = $this->table_downloads();
			$where = $this->GetWhere($flags);
			$orderby = $this->GetOrderBy($order);
			$limit = $this->GetLimit($from);
			$sql = "SELECT id, filename, download_count, last_date, file_exists FROM ${table_downloads} ${where} ${orderby} ${limit}";
			$totalcount = $wpdb->get_var("SELECT COUNT(*) FROM ${table_downloads} ${where}");
			$results = $wpdb->get_results($sql, ARRAY_N);
			$rownum = intval($options['from']);
			if (is_array($results)) {
				foreach ($results as $row) {
					$rownum++;
					list($download, $filename, $count, $date, $exists) = $row;
					?>
	<tr<?php if (!$exists) echo ' class="not-exist"'; ?>>
		<td><?php echo $rownum; ?>.</td>
		<td><?php if ($detailed): ?><a href="<?php echo $this->GetUrlForList(array('download' => $download)); ?>"><?php endif; echo htmlspecialchars($filename); if ($detailed): ?></a><?php endif; ?></td>
		<td><?php echo $count; ?></td>
		<td><?php echo mysql2date('Y-m-d h:i:s', $date, TRUE); ?></td>
		<td><?php if ($this->IsAdmin()): ?><input type="checkbox" name="SimpleDownloadMonitor_DeleteIds[]" value="<?php echo $download; ?>" /><label for="SimpleDownloadMonitor_DeleteIds[]"> <?php echo __('Delete', $this->GETTEXT_REALM); ?></label><?php else: ?>&nbsp;<?php endif; ?></td>
	</tr>
	</tbody><?php
				}
			}
		?>
</table>
<?php if ($this->isAdmin()): ?>
<div><input type="submit" name="SimpleDownloadMonitor_Delete" value="<?php echo __('Delete Checked', $this->GETTEXT_REALM); ?>" /></div>
<div><input type="submit" name="SimpleDownloadMonitor_DeleteAll" value="<?php echo __('Delete All', $this->GETTEXT_REALM); ?>" /> - <input type="checkbox" name="SimpleDownloadMonitor_DeleteAllReally" value="yes" /><label for="SimpleDownloadMonitor_DeleteAllReally"> <?php echo __('Yes, I am sure', $this->GETTEXT_REALM); ?></label></div>
</form>
<?php endif; ?>
<?php echo $this->Paginator($options, $totalcount); ?>
</div><?php
		}

		function DetailedDownloadList($options)
		{
			global $wpdb;
			$flags = $options['flags'];
			$from = $options['from'];
			$order = $options['order'];
			$download = $options['download'];
			$detailed = $options['detailed'];
			$table_downloads = $this->table_downloads();
			list($id, $filename, $count) = $wpdb->get_row($wpdb->prepare("SELECT id, filename, download_count FROM ${table_downloads} WHERE id=%d", $download), ARRAY_N);
			if (!$id)
			{
				$this->DownloadList($options);
				return;
			}
			else
			{
				?>
<div class="wrap">
<h2><?php echo __('Simple Download Monitor', $this->GETTEXT_REALM); ?></h2>
<h3><?php printf(__('Detailed data for <strong>%s</strong>:', $this->GETTEXT_REALM), $filename); ?></h3>
<p><?php printf(__('Total number of downloads: <strong>%d</strong>.', $this->GETTEXT_REALM), $count); ?></p>
<?php if ($this->isAdmin()): ?>
<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<?php endif; ?>
<table id="sdmon">
	<colgroup>
		<col class="sdmon-rownum" align="right" width="32" />
		<col class="sdmon-date" align="center" />
		<col class="sdmon-ipaddr" />
		<col class="sdmon-referer" />
		<col class="sdmon-username" />
		<col class="sdmon-tools" />
	</colgroup>
	<thead>
	<tr>
		<th>&nbsp;</th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_DATE   ))); ?>"><?php echo __("Date", $this->GETTEXT_REALM); ?></a></th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_IP     ))); ?>"><?php echo __("IP address", $this->GETTEXT_REALM); ?></a></th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_REFERER))); ?>"><?php echo __("Referer", $this->GETTEXT_REALM); ?></a></th>
		<th><a href="<?php echo $this->GetUrlForList(array_merge($options, array('order' => self::ORDER_USER   ))); ?>"><?php echo __("Username", $this->GETTEXT_REALM); ?></a></th>
		<th>&nbsp;</th>
	</tr>
	</thead>
	<tbody><?php
				$table_details = $this->table_details();
				$where = $this->GetDetailWhere($flags);
				$orderby = $this->GetDetailOrderBy($order);
				$limit = $this->GetLimit($from);
				$sql = "SELECT id, download_date, ip, referer, userid, username FROM ${table_details} WHERE download=%d ${where} ${orderby} ${limit}";
				$totalcount = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ${table_details} WHERE download=%d ${where}", $download));
				$results = $wpdb->get_results($wpdb->prepare($sql, $download), ARRAY_N);
				$rownum = intval($options['from']);
				foreach ($results as $row) {
					$rownum++;
					list($id, $date, $ip, $referer, $userid, $username) = $row;
					?>
	<tr>
		<td><?php echo $rownum; ?>.</td>
		<td><?php echo mysql2date('Y-m-d h:i:s', $date, TRUE); ?></td>
		<td><?php echo htmlspecialchars($ip); ?></td>
		<td><?php echo htmlspecialchars($referer); ?></td>
		<td><?php echo htmlspecialchars($username); ?></td>
		<td><?php if ($this->IsAdmin()): ?><input type="checkbox" name="SimpleDownloadMonitor_DeleteIds[]" value="<?php echo $id; ?>" /><label for="SimpleDownloadMonitor_DeleteIds[]"> <?php echo __('Delete', $this->GETTEXT_REALM); ?></label><?php else: ?>&nbsp;<?php endif; ?></td>
	</tr>
	</tbody><?php
				}
			}
		?>
</table>
<?php if ($this->isAdmin()): ?>
<div><input type="submit" name="SimpleDownloadMonitor_DeleteDetail" value="<?php echo __('Delete Checked', $this->GETTEXT_REALM); ?>" /></div>
</form>
<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<div><input type="submit" name="SimpleDownloadMonitor_Delete" value="<?php echo __('Delete All', $this->GETTEXT_REALM); ?>" /> - <input type="checkbox" name="SimpleDownloadMonitor_DeleteIds[]" value="<?php echo $download; ?>" /> <?php echo __('Yes, I am sure', $this->GETTEXT_REALM); ?></label></div>
</form>
<?php endif; ?>
<?php echo $this->Paginator($options, $totalcount); ?>
<p><a href="<?php echo $this->GetUrlForList(); ?>"><?php echo __('Return to full list.', $this->GETTEXT_REALM); ?></a></p>
</div><?php
		}

		function ActionHead()
		{
			echo '<link type="text/css" rel="stylesheet" href="' . $this->plugin_url . '/css/sdmon.css" />'."\n";
		}

	}
}

if (!isset($sdmon))
	$sdmon = new SimpleDownloadMonitor();

if (!function_exists('SimpleDownloadMonitor_BuildAdminMenu'))
{
	function SimpleDownloadMonitor_BuildAdminMenu()
	{
		global $sdmon;
		if (isset($sdmon))
		{
			$options_page = add_options_page(__('Simple Download Monitor options', $sdmon->GETTEXT_REALM), __('Simple Download Monitor', $sdmon->GETTEXT_REALM), 'manage_options', basename(__FILE__), array(&$sdmon, 'AdminPanel'));
			$tool_page = add_submenu_page('tools.php', __('Simple Download Monitor', $sdmon->GETTEXT_REALM), __('Simple Download Monitor', $sdmon->GETTEXT_REALM), 'read', basename(__FILE__), array(&$sdmon, 'ToolsPanel'));
			add_action('admin_head-'.$tool_page, array(&$sdmon, 'ActionHead'));
		}
	}
}
